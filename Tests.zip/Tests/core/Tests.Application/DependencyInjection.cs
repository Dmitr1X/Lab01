namespace Tests.Application
{
    public static class DependencyInjection
    {
        
    }
}