namespace Tests.Domain
{
    public static class DependencyInjection
    {
        
    }
}