﻿// See https://aka.ms/new-console-template for more information
using Tests.Presentation.Console;

await DependencyInjection.StartApplication(args);
